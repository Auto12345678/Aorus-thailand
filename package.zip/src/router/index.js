import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },

  {
    path: '/list',
    name: 'List',
    component: () => import('../views/Product_List.vue')
  },
  
  {
    path: '/detail',
    name: 'Detail',
    component: () => import('../views/Product_Detail.vue')
  },

  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About_US.vue')
  },

  {
    path: '/contact',
    name: 'contact',
    component: () => import('../views/Contact_US.vue')
  },
  
  {
    path: '/5060ti',
    name: '5060ti',
    component: () => import('../views/5060ti.vue')
  },

  {
    path: '/mouse',
    name: 'mouse',
    component: () => import('../views/Mouse.vue')
  },

  {
    path: '/login',
    name: 'login',
    component: () => import('../views/Login.vue')
  },

  {
    path: '/re',
    name: 're',
    component: () => import('../views/Register.vue')
  },

  {
    path: '/Z690',
    name: 'Z690',
    component: () => import('../views/Z690.vue')
  },

  {
    path: '/ram',
    name: 'ram',
    component: () => import('../views/RAM.vue')
  },

  {
    path: '/5070',
    name: '5070',
    component: () => import('../views/5070ti.vue')
  },


]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
