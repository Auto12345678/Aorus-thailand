<template>
    <div class="container">
      <div class="px-4 py-5 my-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/MOUSE-removebg-preview.png" alt="" width="400" height="400">
      <h1 class="display-5 fw-bold  text-light">890 บาท</h1>
      
      <div class="col-lg-6 mx-auto">
        <a class="nav-link px-6 text-light text-start">
        <h4>จุดเด่นของเมาส์เกมมิ่ง AORUS M3</h4>
  <ol>
    <li>
      <strong>เซ็นเซอร์ Optical 6400 DPI คุณภาพสูง</strong><br>
      ใช้เซ็นเซอร์ Pixart 3988 ปรับ DPI ได้ละเอียดทีละ 50 DPI<br>
      เหมาะกับเกมเมอร์ที่ต้องการความแม่นยำสูง
    </li>
    <li>
      <strong>สวิตช์ Omron รองรับการคลิก 20 ล้านครั้ง</strong><br>
      ให้ความทนทานและตอบสนองรวดเร็ว<br>
      เหมาะสำหรับการใช้งานระยะยาว
    </li>
    <li>
      <strong>ไฟ RGB Fusion 2.0 และการออกแบบที่จับถนัดมือ</strong><br>
      ปรับแต่งแสงไฟได้ตามต้องการ<br>
      มีพื้นผิวกันลื่นและน้ำหนักสมดุลสำหรับการเล่นเกม
    </li>
  </ol>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-start">
        <a href="">  
            <button type="button" class="btn btn-outline-primary text-">ซื้อเลย</button>
        </a>
        </div>
      </a></div>
    </div> 
   
</div>
</template>