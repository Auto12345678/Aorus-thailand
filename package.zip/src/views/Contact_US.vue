<template>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
      <div class="card shadow-lg p-4 rounded-4" style="max-width: 600px; width: 100%;">
        <h3 class="text-center mb-4 text-dark">แบบสอบถามความพึงพอใจ</h3>
        <form>
          <div class="mb-3">
            <label for="name" class="form-label">ชื่อ-นามสกุล</label>
            <input type="text" class="form-control" id="name" placeholder="กรอกชื่อ-นามสกุล">
          </div>
  
          <div class="mb-3">
            <label for="email" class="form-label">อีเมล</label>
            <input type="email" class="form-control" id="email" placeholder="example@email.com">
          </div>
  
          <div class="mb-3">
            <label for="satisfaction" class="form-label">ความพึงพอใจ</label>
            <select class="form-select" id="satisfaction">
              <option selected disabled>เลือกระดับความพึงพอใจ</option>
              <option value="1">น้อย</option>
              <option value="2">ปานกลาง</option>
              <option value="3">มาก</option>
            </select>
          </div>
  
          <div class="mb-3">
            <label for="comments" class="form-label">ความคิดเห็นเพิ่มเติม</label>
            <textarea class="form-control" id="comments" rows="3" placeholder="เขียนความคิดเห็น..."></textarea>
          </div>
  
          <div class="d-grid">
            <button type="submit" class="btn btn-dark btn-lg rounded-pill">ส่งแบบฟอร์ม</button>
          </div>
        </form>
      </div>
    </div>
  </template>

<style>
body {
  background: linear-gradient(135deg, #1e1f1f, hsla(0, 0%, 7%, 0.925));
}
</style>

  
  