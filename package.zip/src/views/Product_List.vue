<template>
  
    <div class="container">
      
     <div class="row">

    <div class="col-md-4  "><br>
      <div class="card-md-4- zoom-wrapper  " style="width: 18rem; ">
  <img src="../assets/GPU.jpg" class="card-img-top img-fluid zoom-img " alt="สินค้า">
  <div class="card-body text-light img-fluid zoom-img">
    <h5 class="card-title">VGA(การ์ดจอ)NVIDIA RTX 5060Ti</h5>
    <p class="card-text">ราคา 16,300 บาท</p>
    <a href="/5060ti" class="btn btn-light">ซื้อเลย</a>
  </div>
</div>
    </div>

    <div class="col-md-4  "><br>
      <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
  <img src="../assets/RAM.jpg" class="card-img-top img-fluid zoom-img" alt="สินค้า">
  <div class="card-body text-light zoom-img">
    <h5 class="card-title">Ram (แรมพีซี)AORRUS RGB MEMORY 16GB</h5>
    <p class="card-text">ราคา 3,690 บาท</p>
    <a href="/ram" class="btn btn-light">ซื้อเลย</a>
  </div>
</div>
    </div>

    <div class="col-md-4 "><br>
      <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
  <img src="../assets/MOUSE.jpg" class="card-img-top img-fluid zoom-img" alt="สินค้า">
  
  <div class="card-body text-light zoom-img">
    <h5 class="card-title">MOUSE (เมาส์)AORUS M3 GAMING MOUSE </h5>
    <p class="card-text">ราคา 890 บาท</p>
    <a href="/mouse" class="btn btn-light">ซื้อเลย</a>
  </div>
</div>
    </div>
    
     </div>
     <div class="row">

<div class="col-md-4  "><br>
  <div class="card-md-4- zoom-wrapper  " style="width: 18rem; ">
<img src="../assets/5070ti.jpg" class="card-img-top img-fluid zoom-img " alt="สินค้า">
<div class="card-body text-light img-fluid zoom-img">
<h5 class="card-title">VGA(การ์ดจอ)NVIDIA RTX 5070Ti</h5>
<p class="card-text">ราคา 27,300 บาท</p>
<a href="/5070" class="btn btn-light">ซื้อเลย</a>
</div>
</div>
</div>

<div class="col-md-4  "><br>
  <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
<img src="../assets/d28028c6-e2ae-4ca3-813e-35289d83dfb4.png" class="card-img-top img-fluid zoom-img" alt="สินค้า">
<div class="card-body text-light zoom-img">
<h5 class="card-title">SSD 2T AORUS MASTER STIRAGE</h5>
<p class="card-text">ราคา 32,690 บาท</p>
<a href="/detail" class="btn btn-light">ซื้อเลย</a>
</div>
</div>
</div>

<div class="col-md-4 "><br>
  <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
<img src="../assets/gigabyte-z390-aorus-elite-motherboard.webp" class="card-img-top img-fluid zoom-img" alt="สินค้า">
<div class="card-body text-light zoom-img">
<h5 class="card-title">MAINBOARD (เมนบอร์ด) Z390 AORUS</h5>
<p class="card-text">ราคา 1890 บาท</p>
<a href="/detail" class="btn btn-light">ซื้อเลย</a>
</div>
</div>
</div>

 </div>
     <div class="row">
    <div class="col-md-4 "><br>
      <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
  <img src="../assets/SSD.jpg" class="card-img-top img-fluid zoom-img" alt="สินค้า">
  <div class="card-body text-light zoom-img">
    <h5 class="card-title">1 TB SSD (เอสเอสดี)</h5>
    <p class="card-text">ราคา 3,490 บาท</p>
    <a href="/detail" class="btn btn-light">ซื้อเลย</a>
  </div>
</div>
    </div>

    <div class="col-md-4  "><br>
      <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
  <img src="../assets/Main.jpg" class="card-img-top img-fluid zoom-img" alt="สินค้า">
  <div class="card-body text-light zoom-img">
    <h5 class="card-title">MAINBOARD (เมนบอร์ด) Z690 AORUS</h5>
    <p class="card-text">ราคา 7,090 บาท</p>
    <a href="/detail" class="btn btn-light">ซื้อเลย</a>
  </div>
</div>

    </div>
    <div class="col-md-4  "><br>
       <div class="card-md-4 zoom-wrapper" style="width: 18rem;">
  <img src="../assets/COOLER.jpg" class="card-img-top img-fluid zoom-img" alt="สินค้า">
  <div class="card-body text-light zoom-img">
    <h5 class="card-title">LIQUID COOLER (ชุดน้ำปิด)</h5>
    <p class="card-text">ราคา 3,790 บาท</p>
    <a href="/detail" class="btn btn-light">ซื้อเลย</a>
  </div>
</div>
    </div>
     </div><br>
    </div>

    <div class=" container-fluid bg-dark text-secondary px-4 py-5 text-center ">
  <div class="py-5 px-4 ">
    <img src="../assets/logo.png" alt="" width="150" height="120">
    <div class="col-lg-6 mx-auto"><br>
      <p class="fs-5 mb-4 text-start">Our customers include individuals and businesses who trust us for reliable, easy-to-use, and high-quality services tailored to their needs.</p>

    </div>
  </div>
</div>



    </template>

<style>
body {
  background: linear-gradient( #000000c9);
}
</style>


<script>
export default {
  name: 'HoverZoomGallery',
  data() {
    return {
      images: [
        'https://via.placeholder.com/300x200',
        'https://via.placeholder.com/300x200?text=Second',
        'https://via.placeholder.com/300x200?text=Third',
      ],
    };
  },
};
</script>

<style scoped>
.zoom-wrapper {
  overflow: hidden;
  border-radius: 6px;
  box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
}

.zoom-img {
  transition: transform 0.4s ease;
}

.zoom-wrapper:hover .zoom-img {
  transform: scale(1.1);
}
</style>


