<template>
    <div class="container">
      <div class="px-4 py-5 my-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/gigabyte-z390-aorus-elite-motherboard.webp" alt="" width="200" height="200">
      <h1 class="display-5 fw-bold text-body-emphasis">$690</h1>
      
      <div class="col-lg-6 mx-auto">
        <p class="lead mb-6 text-start">Gem for spin.</p>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-start">
        <a href="/list">  
            <button type="button" class="btn btn-outline-primary text-">Buy</button>
        </a>
        <a href="/contact" class="nav-link px-6 text-dark">Contact Us</a>
       
        </div>
      </div>
    </div> 
   
</div>
</template>