<template>
    <div class="container">
      <div class="px-4 py-5 my-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/cooling-alterspin.png" alt="" width="900" height="400">
      <h1 class="display-5 fw-bold  text-light">16300บาท</h1>
      
      <div class="col-lg-6 mx-auto">
        <a class="nav-link px-6 text-light text-start">
        <h4>จุดเด่นของการ์ดจอ RTX 5060 Ti AORUS ELITE</h4>
  <ol>
    <li>
      <strong>ชิปกราฟิกสถาปัตยกรรมใหม่ (Blackwell?)</strong><br>
      ใช้ชิป NVIDIA รุ่นใหม่ล่าสุด เพิ่มประสิทธิภาพ ray tracing<br>
      รองรับ DLSS รุ่นใหม่ ช่วยเร่งเฟรมเรตและภาพสวยขึ้น
    </li>
    <li>
      <strong>แรม GDDR7 หรือ GDDR6X ความเร็วสูง</strong><br>
      ความจุ 8GB – 12GB พร้อมบัสกว้างกว่าเดิม<br>
      รองรับการเล่นเกมระดับ AAA และการทำงานกราฟิก
    </li>
    <li>
      <strong>ดีไซน์สวย ระบายความร้อนด้วย WINDFORCE + ไฟ RGB</strong><br>
      มีพัดลม 3 ตัว ระบบหมุนสลับทิศ เพิ่มประสิทธิภาพการระบายความร้อน<br>
      ไฟ RGB Fusion ปรับแต่งแสงได้ สวยงามทั้งด้านหน้าและหลัง
    </li>
  </ol>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-start">
        <a href="">  
            <button type="button" class="btn btn-outline-primary text-">ซื้อเลย</button>
        </a>
        </div>
      </a></div>
    </div> 
   
</div>
</template>