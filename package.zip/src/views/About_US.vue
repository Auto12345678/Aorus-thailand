<template>
  <div class="d-flex justify-content-center align-items-center min-vh-100">
    <div class="text-center">
      <h1>กรุณาซื้อสินค้า ทางเราจะไม่ให้สินค้า By 67706177</h1>
      
    </div>
  </div>
</template>

<script>
export default {
  name: 'CenteredText'
}
</script>

