<template>
    <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>สมัครสมาชิก</title>
  
</head>
<body>
  <div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="card p-4 col-md-6 col-lg-4 bg-white">
      <h3 class="text-center mb-4">สมัครสมาชิก</h3>
      <form>
        <div class="mb-3">
          <label for="fullname" class="form-label">ชื่อ-นามสกุล</label>
          <input type="text" class="form-control" id="fullname" placeholder="กรอกชื่อ-นามสกุล">
        </div>
        <div class="mb-3">
          <label for="email" class="form-label">อีเมล</label>
          <input type="email" class="form-control" id="email" placeholder="example@email.com">
        </div>
        <div class="mb-3">
          <label for="username" class="form-label">ชื่อผู้ใช้</label>
          <input type="text" class="form-control" id="username" placeholder="username">
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">รหัสผ่าน</label>
          <input type="password" class="form-control" id="password" placeholder="รหัสผ่าน">
        </div>
        <div class="mb-3">
          <label for="confirmPassword" class="form-label">ยืนยันรหัสผ่าน</label>
          <input type="password" class="form-control" id="confirmPassword" placeholder="ยืนยันรหัสผ่าน">
        </div>
        <button type="submit" class="btn btn-dark w-100">สมัครสมาชิก</button>
        <p class="text-center mt-3 mb-0">มีบัญชีอยู่แล้ว? <a href="/login">เข้าสู่ระบบ</a></p>
      </form>
    </div>
  </div>
</body>
</template>

<style>
    body {
      background: linear-gradient(135deg, #1e1f1f, hsla(0, 0%, 7%, 0.925));
      min-height: 100vh;
    }
    .card {
      border-radius: 1rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
    }
    .form-control:focus {
      box-shadow: none;
      border-color: #4a90e2;
    }
  </style>