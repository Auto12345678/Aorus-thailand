<template>
    <div class="container">
      <div class="px-4 py-5 my-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/Main-removebg-preview.png" alt="" width="500" height="400">
      <h1 class="display-5 fw-bold  text-light">7,090 บาท</h1>
      
      <div class="col-lg-6 mx-auto">
        <p class="lead mb-6 text-start text-light"></p>
        <a class="nav-link px-6 text-light text-start">
            <h4>จุดเด่นของเมนบอร์ด Z690 AORUS</h4>
  <ol>
    <li>
      <strong>รองรับ CPU Intel Gen 12 และ 13 พร้อม Overclock ได้</strong><br>
      ใช้ชิปเซ็ต Z690 รองรับซีพียูใหม่ๆ บนซ็อกเก็ต LGA1700<br>
      สามารถโอเวอร์คล็อกได้ทั้ง CPU และ RAM สำหรับสายแรง
    </li>
    <li>
      <strong>รองรับ RAM DDR5 ความเร็วสูง</strong><br>
      บางรุ่นรองรับ DDR5 ได้ถึง 6400MHz+ (OC)<br>
      ให้ประสิทธิภาพเร็วขึ้น เหมาะกับเกมและงานหนัก
    </li>
    <li>
      <strong>เชื่อมต่อครบ PCIe 5.0, M.2 NVMe, USB 3.2, LAN/Wi-Fi</strong><br>
      มีพอร์ตรุ่นใหม่ครบ เช่น PCIe 5.0 สำหรับการ์ดจอ<br>
      รองรับ SSD M.2 หลายตัว พร้อมระบบระบายความร้อนดีเยี่ยม
    </li>
  </ol>
        </a><br>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-start">
        <a href="">  
            <button type="button" class="btn btn-outline-primary text-">ซื้อเลย</button>
        </a>
        </div>
      </div>
    </div> 
   
</div>
</template>