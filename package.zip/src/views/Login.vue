<template>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Login - My Website</title>
</head>
<body>

  <div class="login-card">
    <h2 class="login-title text-dark">Login</h2>
    <form>
      <div class="mb-3">
        <label for="email" class="form-label">Email address</label>
        <input type="email" class="form-control" id="email" placeholder="Enter email">
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" placeholder="Password">
      </div>
      <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="remember">
        <label class="form-check-label" for="remember">Remember me</label>
      </div>
      <button type="submit" class="btn btn-dark">Login</button>
    </form>
  </div>


</body>
</html>
</template>

<style>
    body {
      background: linear-gradient(135deg, #1e1f1f, hsla(0, 0%, 7%, 0.925));
      height: 100vh;
    }
    .login-card {
      max-width: 400px;
      margin: auto;
      margin-top: 10%;
      padding: 2rem;
      background-color: white;
      border-radius: 1rem;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
    }
    .login-title {
      text-align: center;
      margin-bottom: 1.5rem;
      color: #333;
    }
    .btn-primary {
      width: 100%;
    }
    .form-control:focus {
      box-shadow: none;
      border-color: #0d6efd;
    }
  </style>