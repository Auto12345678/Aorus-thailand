<template>
    <div class="container">
      <div class="px-4 py-5 my-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/image-removebg-preview.png" alt="" width="400" height="400">
      <h1 class="display-5 fw-bold  text-light">27,300 บาท</h1>
      
      <div class="col-lg-6 mx-auto">
        <a class="nav-link px-6 text-light text-start">
            <h4>จุดเด่นของการ์ดจอ AORUS GeForce RTX™ 5070 Ti MASTER 16G</h4>
  <ol>
    <li>
      <strong>สถาปัตยกรรม NVIDIA Blackwell 2.0</strong><br>
      ใช้ชิป GPU รุ่นใหม่ล่าสุดจาก NVIDIA พร้อมรองรับ DLSS 4<br>
      ประสิทธิภาพสูง เหมาะสำหรับการเล่นเกมที่ความละเอียด 1440p และ 4K
    </li>
    <li>
      <strong>หน่วยความจำ GDDR7 ขนาด 16GB</strong><br>
      บัส 256-bit ให้แบนด์วิดธ์สูงถึง 896 GB/s<br>
      รองรับการเล่นเกมที่ต้องการแรมมาก เช่น เกม AAA รุ่นใหม่ๆ
    </li>
    <li>
      <strong>ระบบระบายความร้อน WINDFORCE</strong><br>
      พัดลม 3 ตัวพร้อมเทคโนโลยี Hawk Fan และเจลระบายความร้อนเกรดเซิร์ฟเวอร์<br>
      ช่วยให้การ์ดทำงานเงียบและเย็นแม้ในสภาวะการใช้งานหนัก
    </li>
    <li>
      <strong>รองรับ Dual BIOS และไฟ RGB Fusion</strong><br>
      ปรับโหมด BIOS ระหว่าง Performance และ Silent ได้ตามต้องการ<br>
      ปรับแต่งไฟ RGB ได้หลากหลายโหมดผ่านซอฟต์แวร์
    </li>
    <li>
      <strong>รองรับการเชื่อมต่อ PCIe 5.0</strong><br>
      ความเร็วในการส่งข้อมูลสูง เหมาะสำหรับการใช้งานกับเมนบอร์ดรุ่นใหม่ๆ<br>
      รองรับการใช้งานกับระบบ NVIDIA SFF (Small Form Factor)
    </li>
  </ol>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-start">
        <a href="">  
            <button type="button" class="btn btn-outline-primary text-">ซื้อเลย</button>
        </a>
        </div>
      </a></div>
    </div> 
   
</div>
</template>