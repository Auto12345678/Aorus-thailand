<template>
    <div class="container">
      <div class="px-4 py-5 my-5 text-center">
      <img class="d-block mx-auto mb-4" src="../assets/RAM-removebg-preview.png" alt="" width="400" height="400">
      <h1 class="display-5 fw-bold  text-light">3,690 บาท</h1>
      
      <div class="col-lg-6 mx-auto">
        <a class="nav-link px-6 text-light text-start">
            <h4>จุดเด่นของแรม AORUS RGB Memory 16GB (2x8GB)</h4>
  <ol>
    <li>
      <strong>ความเร็วสูงและรองรับ XMP 2.0</strong><br>
      ความเร็ว DDR4-3200MHz (XMP 2.0) พร้อม Latency 16-18-18-38 ที่ 1.35V<br>
      รองรับ AORUS MEMORY BOOST เพื่อเพิ่มประสิทธิภาพ
    </li>
    <li>
      <strong>ดีไซน์สวยงามและไฟ RGB แบบเต็มแถบ</strong><br>
      ไฟ RGB Fusion 2.0 ปรับแต่งได้หลากหลายโหมด<br>
      ออกแบบให้สวยงามและติดตั้งง่าย
    </li>
    <li>
      <strong>ประสิทธิภาพการโอเวอร์คล็อกที่ดี</strong><br>
      สามารถโอเวอร์คล็อกได้ถึง 3733MHz และสูงกว่า<br>
      ใช้ชิป Samsung B-Die ที่มีประสิทธิภาพสูง
    </li>
  </ol>
        <div class="d-grid gap-2 d-sm-flex justify-content-sm-start">
        <a href="">  
            <button type="button" class="btn btn-outline-primary text-">ซื้อเลย</button>
        </a>
        </div>
      </a></div>
    </div> 
   
</div>
</template>