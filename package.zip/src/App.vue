<template>

    <header class="p-3 text-bg-dark">
      <div class="container">
        
        <div class="d-flex flex-wrap align-items- justify-content-center justify-content-lg-" >
           
          <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">
            <svg class="bi me-2" width="40" height="32" role="img"  aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg>
            
          </a>

          <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-start mb-md-0">
            
            <li><a href="/" class="nav-link px-4 text-light">หน้าหลัก</a></li>
            
            <li><a href="/list" class="nav-link px-4 text-light">สินค้า</a></li> 
            
            <li><a href="/contact" class="nav-link px-4 text-light">ความคิดเห็น</a></li>
            <li><a href="/login" class="nav-link px-4 text-light">เข้าสู่ระบบ</a></li>
            <li><a href="/re" class="nav-link px-4 text-light">สมัครสมาชิก</a></li>
          </ul>

          
          
        </div>
      </div>
    </header>
  
  
  
  
  
    <router-view/>
  </template>
  
  